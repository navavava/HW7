// نوا جغتایی-40223025
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void replace(char *start, char *word, int len1, int len2, int sentence); // function that replaces words in a sentence
int main()
{
    int n, flag;
    char a;
    printf("how many words are in each language?\n");
    scanf("%d", &n);
    char list1[n][20], list2[n][20], sentence[256];
    for (int i = 0; i < n; i++)
    {
        printf("enter your words with 1 space in between\n");
        scanf("%s %s", &list1[i], &list2[i]);
    }
    a=getchar();
    printf("enter your sentence:\n");
    fgets(sentence, sizeof(sentence), stdin);
    for (int i = 0; i < 256; i++)
    {
        if (sentence[i] == 0)
        {
            break;
        }
        sentence[i] = tolower(sentence[i]);
    }
    for (int i = 0; i < 256; i++) // checking if any words from list 1 are replacable with words from list 2
    {
        for (int j = 0; j < n; j++)
        {
            flag = 1;
            for (int k = 0; k < strlen(list1[j]); k++)
            {
                if (sentence[i+k] != list1[j][k])
                    flag = 0;
            }
            if (flag)
            {
                if (strlen(list1[j]) > strlen(list2[j]))
                {
                    replace(&sentence[i], list2[j], strlen(list1[j]), strlen(list2[j]), strlen(sentence));
                }
            }
        }
    }
    for (int i = 0; i < 256; i++)
    {
        for (int j = 0; j < n; j++) // checking if any words from list 2 are replacable with words from list 1
        {
            flag = 1;
            for (int k = 0; k < strlen(list2[j]); k++)
            {
                if (sentence[i+k] != list2[j][k])
                    flag = 0;
            }
            if (flag)
            {
                if (strlen(list2[j]) > strlen(list1[j]))
                {
                    replace(&sentence[i], list1[j], strlen(list2[j]), strlen(list1[j]), strlen(sentence));
                }
            }
        }
    }
    printf("%s",sentence);
    return 0;
}

void replace(char *start, char *word, int len1, int len2, int sentence)
{
    for (int i = 0; i < len2; i++)//replacing the words
    {
        start[i] = word[i];
    }
    for (int i = len1; i < sentence; i++)//shifting back the rest of the string
    {
        start[i - len1 + len2] = start[i];
    }
    start[sentence-len1+len2]=0;
}